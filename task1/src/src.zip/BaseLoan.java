public interface BaseLoan {
    int getInterestRate();
    double getAmount();
}