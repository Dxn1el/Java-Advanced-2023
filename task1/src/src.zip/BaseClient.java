public interface BaseClient {
    String getName();
    String getID();
    int getInterest();
    double getIncome();
    void increase();
}
